// ============================================================
// ADMIN ACCESS — contas autorizadas + validação de permissão
//
// PRINCÍPIO: o nome digitado exibido NÃO é prova de identidade.
// Esta camada garante duas coisas no cliente:
//   1) comparação EXATA (case-sensitive) do nome da conta com a
//      allowlist configurada pela administração;
//   2) sessão realmente autenticada (não visitante).
// A validação forte é do servidor (server/ws-server.mjs), que
// verifica a allowlist e assina um token por conta — ver docs.
// Nenhuma senha/chave é mantida neste arquivo.
// ============================================================

/** Allowlist configurada pela administração (case-sensitive, sem trim). */
export const AUTHORIZED_DISPLAY_NAMES: readonly string[] = ["RimuOfc", "Guisdfas"];

export interface AccountInfo {
  id: string;
  username: string;
  isGuest: boolean;
}

export type AccessDenial =
  | "sem-conta"
  | "conta-visitante"
  | "nome-nao-autorizado"
  | "servidor-negou";

export interface AccessResult {
  ok: boolean;
  reason?: AccessDenial;
  scope: "servidor" | "local";
}

/** Comparação EXATA: sem trim, sem lowercase, sem tolerância a variantes. */
export function matchesAuthorizedName(username: unknown): boolean {
  if (typeof username !== "string") return false;
  return AUTHORIZED_DISPLAY_NAMES.some((allowed) => username === allowed);
}

/** Avalia o acesso local (conta autenticada + nome exato da allowlist). */
export function evaluateLocalAccess(account: AccountInfo | null): { ok: boolean; reason?: AccessDenial } {
  if (!account) return { ok: false, reason: "sem-conta" };
  if (account.isGuest) return { ok: false, reason: "conta-visitante" };
  if (!matchesAuthorizedName(account.username)) return { ok: false, reason: "nome-nao-autorizado" };
  return { ok: true };
}

export type ServerPermissionMode = "unconfigured" | "granted" | "denied";

interface ServerPermissionState {
  mode: ServerPermissionMode;
  token: string | null;
  checkedAt: number | null;
}

let serverPermission: ServerPermissionState = { mode: "unconfigured", token: null, checkedAt: null };

/**
 * Consulta a permissão no servidor quando um backend autoritativo estiver
 * conectado (server/ws-server.mjs, rota /admin/permission).
 * Se não houver servidor configurado, o estado permanece "unconfigured".
 */
export async function requestServerPermission(account: AccountInfo): Promise<ServerPermissionState> {
  const endpoint = getAdminApiBase();
  if (!endpoint) {
    serverPermission = { mode: "unconfigured", token: null, checkedAt: null };
    return serverPermission;
  }
  try {
    const res = await fetch(`${endpoint}/admin/permission`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountId: account.id, displayName: account.username }),
    });
    if (!res.ok) {
      serverPermission = { mode: "denied", token: null, checkedAt: Date.now() };
      return serverPermission;
    }
    const data = (await res.json()) as { granted?: boolean; token?: string };
    serverPermission = data.granted
      ? { mode: "granted", token: data.token ?? null, checkedAt: Date.now() }
      : { mode: "denied", token: null, checkedAt: Date.now() };
  } catch {
    // Servidor inacessível: NÃO conceder por conta própria.
    serverPermission = { mode: "denied", token: null, checkedAt: Date.now() };
  }
  return serverPermission;
}

function getAdminApiBase(): string | null {
  try {
    return localStorage.getItem("knox-admin-api") || null;
  } catch {
    return null;
  }
}

export function getServerPermissionState(): ServerPermissionState {
  return { ...serverPermission };
}

export function resetServerPermission() {
  serverPermission = { mode: "unconfigured", token: null, checkedAt: null };
}

/**
 * Revalidação executada antes de CADA ação privilegiada.
 * - Servidor configurado: exige "granted" (token válido).
 * - Sem servidor: permite apenas com aviso de escopo "local".
 */
export function revalidate(account: AccountInfo | null): AccessResult {
  const local = evaluateLocalAccess(account);
  if (!local.ok) return { ok: false, reason: local.reason, scope: "local" };

  if (serverPermission.mode === "denied") {
    return { ok: false, reason: "servidor-negou", scope: "servidor" };
  }
  if (serverPermission.mode === "granted") {
    return { ok: true, scope: "servidor" };
  }
  // unconfigured: permitido apenas no escopo local, com aviso visível na UI
  return { ok: true, scope: "local" };
}

export const ACCESS_REASON_TEXT: Record<AccessDenial, string> = {
  "sem-conta": "Faça login com uma conta autorizada.",
  "conta-visitante": "Contas de visitante não possuem permissão administrativa.",
  "nome-nao-autorizado": "Esta conta não tem permissão de administrador.",
  "servidor-negou": "O servidor negou a permissão administrativa.",
};
