# 🧟 Zomboid Web — Multiplayer Server

Real-time WebSocket server for Knox County multiplayer.

## Quick Start

```bash
cd server
npm install
node ws-server.mjs
```

Server runs on `ws://localhost:8080`

## 🚀 Deploy to Cloud Platforms

### Railway (Recommended - Free Tier)

1. Go to [railway.app](https://railway.app)
2. Create new project → "Deploy from GitHub"
3. Point to the `server/` directory
4. Railway auto-detects Node.js and deploys
5. Copy the generated URL (e.g., `wss://your-app.up.railway.app`)
6. Enter the URL in the game's Server panel

**Cost:** Free tier includes 500 hours/month

### Fly.io (Edge Locations - Low Latency)

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Login
fly auth login

# Deploy
cd server
fly launch --now
```

**Cost:** Free tier includes 3 small VMs, 160GB data transfer

### AWS EC2 (Full Control)

1. Launch EC2 `t2.micro` (free tier)
2. Security Group: open TCP port 8080
3. SSH into instance:
```bash
sudo yum update -y
curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
sudo yum install nodejs -y
# Upload files via scp or git clone
npm install
node ws-server.mjs
```
4. Connect with `wss://<your-ec2-ip>:8080`

**Cost:** Free tier: 750 hours/month t2.micro

### Render (Free with Cold Start)

1. Go to [render.com](https://render.com)
2. New → Web Service
3. Connect GitHub → select `server/` directory
4. Build Command: `npm install`
5. Start Command: `node ws-server.mjs`
6. Auto-deploys with URL

**Cost:** Free tier (cold starts after 15 min inactivity)

### Google Cloud Run

```bash
# Deploy using Cloud Run
gcloud run deploy zomboid-server \
  --source ./server \
  --platform managed \
  --region us-central1 \
  --port 8080 \
  --allow-unauthenticated
```

**Cost:** 2M requests/month free

### Vercel (WebSocket via Edge Functions)

Vercel doesn't natively support WebSocket. Use the `ws-server.mjs` with a separate hosting like Railway instead.

### Heroku

```bash
# Install Heroku CLI
heroku create zomboid-web-server
heroku buildpacks:set heroku/nodejs
git subtree push --prefix server heroku main
```

### DigitalOcean App Platform

1. Go to [digitalocean.com](https://digitalocean.com)
2. Create → Apps
3. Connect GitHub → select `server/`
4. Type: "Worker" (not Web Service)
5. Run command: `node ws-server.mjs`

## 📡 API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /` | Server status page (auto-refresh) |
| `GET /health` | JSON health check with player count |
| `WS /` | WebSocket multiplayer connection |

## 🔧 Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | 8080 | Server listening port |

## 📊 Monitor

The server exposes a beautiful status page at `http://localhost:8080` showing:
- Connected players
- Peak players
- Total connections
- Uptime
- Individual player stats

## 🛡️ Security Notes

- WebSocket connections accept all messages (no auth)
- For production, add JWT authentication
- Consider rate limiting to prevent abuse
- Use HTTPS/WSS (not WS) for browser security
- The `ws` package supports TLS

## 🔧 Scaling

For 100+ concurrent players:
1. Use a process manager like PM2: `pm2 start ws-server.mjs -i max`
2. Deploy behind a load balancer (AWS ALB, Nginx)
3. Use Redis Pub/Sub for multi-server sync
4. Consider Kubernetes for auto-scaling

## 🎮 Client Connection

In the game's Server Configuration panel:
1. Enter your server URL: `wss://your-app.railway.app:8080`
2. Click Connect
3. Open multiple browser tabs or share the URL with friends
4. Everyone sees each other in the same Knox County!
