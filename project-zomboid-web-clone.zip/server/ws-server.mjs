// ============================================================
// Zomboid Web — WebSocket Multiplayer Server
// Deploy to: AWS EC2, Railway, Render, Fly.io, Vercel (serverless), VPS
// Run: node ws-server.mjs
// ============================================================

import { createServer } from "http";
import { WebSocketServer } from "ws";

const PORT = process.env.PORT || 8080;
const TICK_RATE = 10; // 10 updates per second
const TIMEOUT = 15000;

// Game state
const players = new Map();
const chatHistory = [];
const zombies = []; // Server-authoritative zombies (optional)

// Stats
let totalConnections = 0;
let peakPlayers = 0;
const startTime = Date.now();

// Create HTTP server with status page
const httpServer = createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({
      status: "online",
      players: players.size,
      peak: peakPlayers,
      uptime: Math.floor((Date.now() - startTime) / 1000),
      totalConnections,
    }));
    return;
  }

  if (req.url === "/") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(getStatusPage());
    return;
  }

  res.writeHead(404);
  res.end("Not found");
});

// WebSocket server
const wss = new WebSocketServer({ server: httpServer });

wss.on("connection", (ws, req) => {
  const playerId = `srv-${Math.random().toString(36).slice(2, 10)}`;
  totalConnections++;
  const startTime = Date.now();

  const player = {
    id: playerId,
    name: "",
    x: 0,
    y: 0,
    angle: 0,
    health: 100,
    kills: 0,
    lastUpdate: Date.now(),
    ws,
    pingStart: 0,
    connected: true,
  };

  players.set(playerId, player);

  // Send player their ID
  ws.send(JSON.stringify({
    type: "assignId",
    id: playerId,
    serverTime: Date.now(),
    playerCount: players.size,
  }));

  ws.on("message", (data) => {
    try {
      const msg = JSON.parse(data.toString());
      handleMessage(playerId, msg);
    } catch {
      // Invalid JSON
    }
  });

  ws.on("close", () => {
    players.delete(playerId);
    broadcastToAll({
      type: "leave",
      id: playerId,
      name: player.name,
      x: player.x,
      y: player.y,
      angle: player.angle,
      health: player.health,
      kills: player.kills,
      ts: Date.now(),
    }, playerId);
    peakPlayers = Math.max(peakPlayers, players.size);
  });

  ws.on("error", () => {
    players.delete(playerId);
  });

  // Send existing players to new connection
  for (const [id, p] of players) {
    if (id !== playerId && p.connected) {
      ws.send(JSON.stringify({
        type: "state",
        id: p.id,
        name: p.name,
        x: p.x,
        y: p.y,
        angle: p.angle,
        health: p.health,
        kills: p.kills,
        ts: Date.now(),
      }));
    }
  }

  // Send chat history
  for (const msg of chatHistory.slice(-20)) {
    ws.send(JSON.stringify(msg));
  }
});

function handleMessage(playerId, msg) {
  const player = players.get(playerId);
  if (!player) return;

  if (msg.id && msg.id !== playerId) return; // Ignore spoofed messages

  switch (msg.type) {
    case "join":
    case "state":
    case "heartbeat":
      player.name = msg.name || player.name;
      player.x = msg.x;
      player.y = msg.y;
      player.angle = msg.angle;
      player.health = msg.health;
      player.kills = msg.kills;
      player.lastUpdate = Date.now();

      // Broadcast to all other players
      broadcastToAll({
        type: "state",
        id: playerId,
        name: player.name,
        x: player.x,
        y: player.y,
        angle: player.angle,
        health: player.health,
        kills: player.kills,
        ts: Date.now(),
      }, playerId);
      break;

    case "leave":
      players.delete(playerId);
      broadcastToAll({
        type: "leave",
        id: playerId,
        name: player.name,
        x: 0, y: 0, angle: 0,
        health: 0, kills: 0, ts: Date.now(),
      }, playerId);
      break;

    case "chat":
      if (msg.chatText) {
        const chatMsg = {
          type: "chat",
          id: playerId,
          name: player.name,
          x: player.x,
          y: player.y,
          angle: player.angle,
          health: player.health,
          kills: player.kills,
          ts: Date.now(),
          chatText: msg.chatText.slice(0, 200), // Limit message length
        };
        chatHistory.push(chatMsg);
        if (chatHistory.length > 100) chatHistory.shift();
        broadcastToAll(chatMsg, null); // Include sender
      }
      break;

    case "ping":
      // Return ping for latency measurement
      player.ws.send(JSON.stringify({
        type: "ping",
        id: "server",
        ts: msg.ts,
        serverTime: Date.now(),
        x: 0, y: 0, angle: 0, health: 0, kills: 0,
        name: "Server",
      }));
      break;
  }
}

function broadcastToAll(msg, excludeId) {
  const data = JSON.stringify(msg);
  for (const [id, player] of players) {
    if (id !== excludeId && player.ws.readyState === 1) {
      try {
        player.ws.send(data);
      } catch {
        // Connection broken
      }
    }
  }
}

// Server tick - clean up stale connections
setInterval(() => {
  const now = Date.now();
  for (const [id, player] of players) {
    if (now - player.lastUpdate > TIMEOUT) {
      players.delete(id);
      broadcastToAll({
        type: "leave",
        id,
        name: player.name,
        x: 0, y: 0, angle: 0,
        health: 0, kills: 0, ts: now,
      }, id);
    }
  }
  peakPlayers = Math.max(peakPlayers, players.size);
}, 5000);

// Start server
httpServer.listen(PORT, () => {
  console.log(`\n${"═".repeat(60)}`);
  console.log(`  🧟 Zomboid Web — Multiplayer Server`);
  console.log(`  📍 WebSocket: ws://localhost:${PORT}`);
  console.log(`  🌐 Status:    http://localhost:${PORT}`);
  console.log(`  ❤️  Health:    http://localhost:${PORT}/health`);
  console.log(`  ⚙️  Tick Rate: ${TICK_RATE}/s`);
  console.log(`${"═".repeat(60)}\n`);
});

function getStatusPage() {
  const uptime = Math.floor((Date.now() - startTime) / 1000);
  const hours = Math.floor(uptime / 3600);
  const mins = Math.floor((uptime % 3600) / 60);
  const secs = uptime % 60;

  return `<!DOCTYPE html>
<html><head><title>Zomboid Web Server</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #111; color: #d7c9a7; font-family: 'Courier New', monospace; padding: 2rem; min-height: 100vh; }
  h1 { color: #d96b3a; font-size: 2rem; margin-bottom: 1rem; }
  .card { border: 1px solid #2a2a2a; background: #151515; padding: 1.5rem; margin-bottom: 1rem; }
  .stat { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #2a2a2a; }
  .stat:last-child { border: none; }
  .label { color: #7f936f; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.1em; }
  .value { color: #d96b3a; font-size: 1.2rem; font-weight: bold; }
  .status { display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #4aff4a; margin-right: 0.5rem; }
  .players { margin-top: 1rem; }
  .player-item { padding: 0.3rem 0; font-size: 0.8rem; color: #5a8aaa; border-bottom: 1px solid #1f2521; }
</style>
<meta http-equiv="refresh" content="5">
</head>
<body>
  <h1>🧟 Zomboid Web Server</h1>
  <div class="card">
    <div class="stat"><span class="label">Status</span><span class="value"><span class="status"></span>ONLINE</span></div>
    <div class="stat"><span class="label">Uptime</span><span class="value">${hours}h ${mins}m ${secs}s</span></div>
    <div class="stat"><span class="label">Port</span><span class="value">${PORT}</span></div>
    <div class="stat"><span class="label">Tick Rate</span><span class="value">${TICK_RATE}/s</span></div>
  </div>
  <div class="card">
    <div class="stat"><span class="label">Connected Players</span><span class="value">${players.size}</span></div>
    <div class="stat"><span class="label">Peak Players</span><span class="value">${peakPlayers}</span></div>
    <div class="stat"><span class="label">Total Connections</span><span class="value">${totalConnections}</span></div>
  </div>
  <div class="card">
    <h2 style="font-size: 0.9rem; color: #7f936f; margin-bottom: 0.5rem; text-transform: uppercase; letter-spacing: 0.1em;">Active Players</h2>
    ${players.size === 0 ? '<p style="color: #666;">No players connected</p>' : ''}
    ${Array.from(players.values()).map(p => `<div class="player-item">👤 ${p.name || 'Unnamed'} — HP: ${Math.round(p.health)} — Kills: ${p.kills}</div>`).join('')}
  </div>
</body></html>`;
}
