// ═══════════════════════════════════════════════════════════════
//  PADDLE SERVER CONFIG — SERVER SIDE ONLY
//
//  ⚠️  This file lives OUTSIDE src/ so Vite never bundles it into
//      the browser. The secret API key below grants full control of
//      your Paddle account (refunds, cancellations, customer data).
//      In production move it to an environment variable / secret
//      manager and NEVER commit this file.
// ═══════════════════════════════════════════════════════════════

export const PADDLE = {
  /** Secret API key — server use only. */
  apiKey: process.env.PADDLE_API_KEY || "pdl_live_apikey_01m0zkjk97xzq4mgr1tgytee4y_4KZQm5GbSZhZs1r998mHyH_Abz",

  /** Secondary/live API key provided for the account. */
  apiKeyAlt: process.env.PADDLE_API_KEY_ALT || "apikey_01m1x2yjsxzthaew4se2dw8b6q",

  /** Public client-side token (safe in the browser). */
  clientToken: process.env.PADDLE_CLIENT_TOKEN || "live_f1f4f92feb3c52abacfef399136",

  /** Webhook signing secret — Paddle → Developer tools → Notifications. */
  webhookSecret: process.env.PADDLE_WEBHOOK_SECRET || "pdl_whsec_replace_with_your_notification_secret",

  /** "sandbox" or "production" — must match the API key prefix. */
  environment: (process.env.PADDLE_API_KEY || "pdl_live_").includes("live") ? "production" : "sandbox",
};

export const API_BASE =
  PADDLE.environment === "production" ? "https://api.paddle.com" : "https://sandbox-api.paddle.com";

export const SERVER_PORT = Number(process.env.PORT || 8787);

/** Persisted webhook log + entitlement mirror (swap for Postgres in prod). */
export const DATA_FILE = new URL("./data/entitlements.json", import.meta.url).pathname;
export const LOG_FILE = new URL("./data/webhook-log.json", import.meta.url).pathname;
